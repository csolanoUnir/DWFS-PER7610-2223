export const Button = ({ texto }) => {
    return <button className="btn btn-sm btn-outline-secondary" type="button">{texto}</button>

};
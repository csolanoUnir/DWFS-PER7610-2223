import './../styles/Navbar.css';
import { Button } from '../components/Button';

export const Navbar = () => {
    return <div className="navbar">
        <nav className="navbar navbar-light bg-light">
            <form className="form-inline">
                <Button texto="Mi Perfil"/>
                <Button texto="Estudios"/>
                <Button texto="Experiencias"/>
                <Button texto="Hobbies"/>
            </form>
        </nav>
    </div>
};
import './../styles/Card.css';
import foto from '../img/FotoSel.jpeg';
import './../styles/App.css';

export const Card = () => {
    return <div className="card">
         <img src={foto} class="card-foto" alt="FotoSel"></img>
            <div className="card-body">
                <h5 className="card-title">Mi perfil</h5>
                <p className="card-text">Soy fans de la lealtad y empatía en las personas. Me gustaría que me sigas en mis redes sociales.</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">Pérez Mera Selena Liceth</li>
                <li className="list-group-item">25 años</li>
                <li className="list-group-item">Feliz y enamorada de la vida</li>
            </ul>
            <div className="card-body">
                <a href="https://www.facebook.com/Selena.Liss" className="card-link">Facebook</a>
                <a href="https://www.instagram.com/selenalissperez/" className="card-link">Instagram</a>
                <a href="https://wa.me/qr/RQNRCFCFPQETI1" className="card-link">WhatsApp</a>
            </div>
    </div>
};